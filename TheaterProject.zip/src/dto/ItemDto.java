package dto;

public class ItemDto {

}
